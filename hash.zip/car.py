class Car:
  def __init__(self, length, path):
    self.length = length
    self.path = path
    self.current = path[0]

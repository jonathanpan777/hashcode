class Street:
  def __init__(self, start, end, name, length):
    self.start = start
    self.end = end
    self.name = name
    self.length = length